Drag GandyClientBeta to ./minecraft/versions
Drag gandyclient to ./minecraft/libraries
note: must have OptiFine:1.8.9_HD_U_M5 installed
https://optifine.net/adloadx?f=OptiFine_1.8.9_HD_U_M5.jar&x=bf57
